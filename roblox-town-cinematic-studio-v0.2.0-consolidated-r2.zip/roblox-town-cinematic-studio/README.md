# Roblox Town Cinematic Studio

**Version:** `0.2.0-consolidated` (built on frozen `v0.1.1` RC6 baseline) — One Prompt → One Finished Video *(evaluation suite execution, model-tier/capability benchmarks, live TTS provider verification, and physical filming validation remain pending)*.

An open-source, hardware-independent, model-routed, provider-independent [Agent Skill](https://agentskills.io/specification) (`roblox-town-director`) for coordinating specialized AI models and creative production tools across storytelling, voicing, code-driven filmmaking, editing, and packaging for Roblox town, roleplay, and animated Roblox stories.

## Product Identity

`roblox-town-director` is **one canonical creative and production director**—built to coordinate specialized models and actual creative software across frontier, mid-sized, free, small local, and open-source AI agents without duplicating provider forks. It covers:

- **Intelligence Router & Model Capability Registry:** Task-based routing across 11 defined routing capabilities (`creative_reasoning`, `storytelling`, `research`, `coding`, `image_generation`, `video_generation`, `3d_and_animation`, `text_to_speech`, `audio_processing`, `video_editing`, `quality_assessment`), 4 adaptive modes (`AUTOMATIC`, `MANUAL`, `BUDGET`, `RESOURCE_EFFICIENT`), and a 6-step model-substitution recovery loop (`references/intelligence-router.md`, `templates/model-capability-registry.json`).
- **Adaptive Intelligence & Task Decomposition:** Three execution profiles (`FRONTIER`, `BALANCED`, `RESOURCE_EFFICIENT`), hierarchical production graphs (`Film -> Acts -> Chapters -> Sequences -> Scenes -> Shots -> Assets`), minimal context slicing for smaller models, and a 5-step Scene QC Loop (`references/adaptive-intelligence.md`, `references/task-decomposition.md`, `templates/task-graph-template.json`).
- **Code-Driven Filmmaking Guide:** Environment-gated procedural control (FFmpeg + Python, Roblox Studio + Luau, Blender + Python, Remotion) paired with generative AI assets and mandatory export verification (`references/code-driven-filmmaking.md`).
- **Voice Intelligence & Authorized Cloning (`scripts/voice_intelligence/`):** Modular Voice Profile Manager, Voice Design, consent-gated Authorized Voice Cloning (`independent_identity_verified: false` self-attestation boundary), provider-independent adapter system (`ElevenLabsAdapter` supporting connector-authenticated transports, in-memory `credential_provider` callbacks, and `ELEVENLABS_API_KEY` env fallback without exposing keys in env/logs/reports [mock-tested; live API unverified]; remote voice cloning is unconditionally disabled at both `AuthorizedVoiceCloner` and `ElevenLabsAdapter.create_authorized_clone()`, `OpenAITTSAdapter` & `GoogleCloudTTSAdapter` [contract-only], and `RecordedVoiceProviderAdapter` [locally verified]), automatic persistent character assignment (no silent substitution), resumable dialogue pipeline, FFmpeg `mux_audio_and_subtitles_to_video` (with `preserve_source_audio: bool = False`), CLI entrypoint (`scripts/voice_intelligence/__main__.py`), acceptance criteria (`evaluations/voice-intelligence-acceptance.md`), and **82 automated tests** (`8/8` in `tests/test_voice_backend.py` + `40/40` in `tests/test_voice_intelligence.py` + `34/34` in `tests/test_v020_production.py`, including real FFmpeg rendering of all 15 caption presets `C01`–`C15` + `C16` Auto Adaptive, multi-scene `xfade` assembly & `sidechaincompress` BGM ducking, black-frame detection & PIL contact sheets, `F-12` FFprobe recovery verification, `F-13` SHA-256 caption receipt verification, `F-14` direct BYO/TTS voice-stage execution & recovery in `autopilot.py`, and `F-15` dialogue truncation protection; remote voice cloning remains disabled until independent verification exists; GitHub Actions workflow defined in `.github/workflows/ci.yml`, not yet executed remotely). Known limitation: `run_script_pipeline` schedules script dialogue sequentially; custom overlapping timestamps are supported via `voice_backend.py` manifests.
- **Six-Voice Identity & Continuity System (`V01`–`V06`):** Provider-independent voice registry (`templates/voice-registry.json`), persistent `character_id -> voice_id -> provider_voice_id` continuity manifest (`templates/project-voice-manifest.json`), voice direction rules, and a universal 10-capability provider adapter contract.
- **Storytelling, Cinematic Direction & Continuity:** Including the *"In This Town..."* Shorts format, shot-scale variation, active blocking, prop-state visual truth, flashback differentiation, 180-degree continuity, and coherent safe-margin captions (`references/storytelling.md`, `references/cinematic-direction.md`).
- **6 Natural-Language Operating Modes:** `IDEA`, `SCRIPT`, `SHOOT`, `POST`, `REVIEW`, and `FULL`.

## Six-Voice Identity System (Provider-Independent)

Internal voice IDs never change when you switch TTS providers or AI agents:

| ID | Identity | Intended Roles | Safety & Reference Policy |
| :--- | :--- | :--- | :--- |
| **`V01`** | My Reference Voice | Primary narrator / creator-selected lead | Anchored to private reference clips (kept out of public repos); requires provider eligibility, rights, and consent verification. |
| **`V02`** | Mature Adult Male | Fathers, leaders, mentors, authority, historical roles | Licensed synthetic or provider-cleared voice; no movie-trailer caricature. |
| **`V03`** | Teenage Boy | Teen protagonists, friends, school roles | **Fictional synthetic only**—never clone real minors. |
| **`V04`** | Mature Adult Female | Mothers, teachers, leaders, narrators | Licensed synthetic or provider-cleared voice. |
| **`V05`** | Teenage Girl | Teen protagonists, friends, school roles | **Fictional synthetic only**—never clone real minors. |
| **`V06`** | Elder Storyteller | Grandparents, elders, historical/flashback narration | Licensed synthetic or provider-cleared voice; no caricatured speech. |

**Configuring Your Own Voice Provider:** Edit `provider_binding` inside `skills/roblox-town-director/templates/voice-registry.json` (and `active_provider` in `project-voice-manifest.json`) only after verifying your chosen provider's actual capabilities against `references/voice-provider-adapter.md`. Never commit private reference audio recordings or API keys to a public repository.

## Universal Platform Compatibility

There is **one canonical skill** stored at `skills/roblox-town-director/SKILL.md`. Because native discovery paths, import mechanisms, and media/TTS tools differ by client, do not assume cloning the repository activates the skill automatically—follow the platform guide below:

| Platform | Installation Model | Guide |
| :--- | :--- | :--- |
| **Claude Code** | Native filesystem skill (`.claude/skills/` or `~/.claude/skills/`) | [integrations/claude-code.md](integrations/claude-code.md) |
| **Claude App** | Custom Skill ZIP upload (plan & code execution required); Projects alternative | [integrations/claude-app.md](integrations/claude-app.md) |
| **OpenAI Codex** | Native `.agents/skills/` or `~/.agents/skills/` (symlinks supported) | [integrations/codex.md](integrations/codex.md) |
| **ChatGPT** | Desktop standalone Skill; plugin distribution for Chat/Work; Project/GPT adapter | [integrations/chatgpt.md](integrations/chatgpt.md) |
| **Gemini CLI** | Native `.gemini/skills/` or `.agents/skills/`; `gemini skills install` / `link` | [integrations/gemini-cli.md](integrations/gemini-cli.md) |
| **Google AI Studio** | Manual system-instruction / API adapter | [integrations/ai-studio.md](integrations/ai-studio.md) |
| **Other Agents (e.g., Muse AI)** | Unverified / Markdown fallback (load `SKILL.md` + needed `references/*.md`) | — |

## Recorded Voice Backend (Optional Local Execution)

For importing, validating, normalizing, and timeline-assembling creator-supplied voice recordings (`V01`–`V06`) without an external TTS API, run `skills/roblox-town-director/scripts/voice_backend.py`:

- **Dependencies:** Python 3.9+ (standard library only) and `ffmpeg` / `ffprobe` installed on `PATH`.
  - **Linux (Debian/Ubuntu):** `sudo apt-get install ffmpeg`
  - **macOS (Homebrew):** `brew install ffmpeg`
  - **Windows (winget):** `winget install Gyan.FFmpeg`
  - **Android (Termux):** `pkg install python ffmpeg`
- **Automated Regression Tests:** `python3 -m unittest discover -s tests -v` (`tests/test_voice_backend.py`)
- **Example & Test Project:** See `examples/recorded-voice-test-project/` (tests WAV/MP3 import, trimming, normalization, invalid-file rejection, missing-file handling, and timeline + SRT assembly). External TTS remains unimplemented in this local backend.

## Repository Structure

```text
roblox-town-cinematic-studio/
├── README.md
├── LICENSE
├── CHANGELOG.md
├── skills/
│   └── roblox-town-director/
│       ├── SKILL.md
│       ├── references/
│       │   ├── intelligence-router.md
│       │   ├── adaptive-intelligence.md
│       │   ├── task-decomposition.md
│       │   ├── code-driven-filmmaking.md
│       │   ├── storytelling.md
│       │   ├── cinematic-direction.md
│       │   ├── production-workflow.md
│       │   ├── editing-and-packaging.md
│       │   ├── voice-identity-lock.md
│       │   ├── voice-direction.md
│       │   ├── continuity-management.md
│       │   └── voice-provider-adapter.md
│       ├── templates/
│       │   ├── short-production-packet.md
│       │   ├── mini-movie-outline.md
│       │   ├── model-capability-registry.json
│       │   ├── task-graph-template.json
│       │   ├── voice-registry.json
│       │   ├── caption-styles.json
│       │   └── project-voice-manifest.json
│       ├── scripts/
│       │   ├── autopilot.py
│       │   ├── caption_styles.py
│       │   ├── production_state.py
│       │   ├── video_assembler.py
│       │   ├── visual_qc.py
│       │   ├── voice_backend.py
│       │   └── voice_intelligence/
│       │       ├── __init__.py
│       │       ├── __main__.py
│       │       ├── audio_qc.py
│       │       ├── character_assignment.py
│       │       ├── pipeline.py
│       │       ├── profile_manager.py
│       │       ├── providers.py
│       │       ├── voice_cloning.py
│       │       └── voice_design.py
│       ├── examples/
│       │   └── solo-short-example.md
│       └── evaluations/
│           ├── test-suite.md
│           ├── model-tier-benchmark.md
│           └── voice-intelligence-acceptance.md
├── .github/
│   └── workflows/
│       └── ci.yml
├── examples/
│   └── recorded-voice-test-project/
│       ├── README.md
│       ├── generate_synthetic_fixtures.py
│       └── project-voice-manifest.json
├── tests/
│   ├── test_voice_backend.py
│   ├── test_v020_production.py
│   └── test_voice_intelligence.py
└── integrations/
    ├── claude-code.md
    ├── claude-app.md
    ├── codex.md
    ├── chatgpt.md
    ├── gemini-cli.md
    └── ai-studio.md
```

## What It Does Not Do

- Does not assume physical Roblox gameplay capture, device control, or media/video rendering unless the active agent has verified tools and permissions for those stages; when a stage is unavailable, it executes every supported stage and reports only the blocked stages with practical alternatives.
- Does not bundle a hardcoded TTS provider, fabricate provider Voice IDs, invent model benchmark scores, or claim audio/video was generated when no actual file exists.
- Does not invent game props, emotes, or camera controls—uncertain features are marked `UNVERIFIED` with a 1-minute in-game check and fallback.
- Does not claim live platform execution, live TTS verification, or passed evaluation/benchmark scores until those tests are actually run.

## License

MIT — see [LICENSE](LICENSE).
